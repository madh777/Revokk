<body id="top" data-spy="scroll">



<?php require $this->header; ?>


<div   style='height:100%; margin:0px; width:100%; background-image:url(<?=URL?>/public/images/slider/slider1.jpg); '>
<div style='margin:0px'>
            <div style='padding-top:10%; padding-left:10px; width:400px; margin-left: 0 auto; margin-right: 0 auto;'>
                    
                    <div style='background-image:url(<?=URL?>/assets/img/black.png); width:100%; color:white; padding:20px;'/> 
                    <h1 style='font-size:400%'> <?=APP_NAME?> </h1><hr>
                    <p style='font-size:150%'>
                     <?=APP_NAME?> gives you an opportunity to earn 30%  for all donations.<br>For sustainability, donations are set at minimum $40.
Maximum $450

                    </p>
                    </div>
            </div>
</div>
    </div>


    <div class="container">

            <div class="row">
                <br>
              

                <div class="col-lg-12">
                    <div class="panel panel-default about-app" >
                        <div class="panel-body text-center"> 
                            <h1>How It Works</h1>  <hr>
                                                      After you register/login, to access your account.
From your dashboard page you click on the 'make donation' button.
Simply pick someone who is to receive money from the list, input amount in dollars not less than $40 (&#8358;20000) or more than $500 (&#8358;25000) and click on 'reserve'.
You choose to pay either part or the entire money the person is to receive as splitting within minimum and maximum amount ranges is allowed.
Once your payment has been confirmed you would be queued on the list to be paid 130% of the money you donated i.e you get 130% interest. 
Get paid too and don't be greedy, redonate to other users too and earn more.
However we give no guarantees and promises! Neither explicit nor implicit .
                
                        </div>
                    </div>
                </div>  
<hr>
                <div class="col-lg-12">
                    <div class="panel panel-default about-app">
                        <div class="panel-body text-center"> 
                            <h1>About Us</h1> <hr>
                            <p>
<p>
<h2><u>Our Mission</u></h2>

We are a community of people, willing and ready to invest in a system to help each other. We simply provide a platform to connect participants to be able to invest by reserving each other for payment and receive incentives in return. We are determined to sustain this platform to help as much people as possible. The earlier you join the better, as your participation is handomely rewarded and someone out there needs your help today.
</p>
<p>
<h2><u>Our Philosophy</u></h2>

Only by giving are you able to receive more than you already have.
                                      Jim Rohn. 
Our efforts are geared towards ensuring that all participants who invest must get return on their investments. This is achieved by keeping away u serious minded individuals and cyber Eggers from the system.</p>  </p>         
                
                        </div>
                    </div>


                      <div class="col-lg-12">
                    <div class="panel panel-default about-app">
                        <div class="panel-body text-center"> 
                            <h1>Benefits</h1> <hr>
                            <p>
<p>

<ul class="list-group">
<li class="list-group-item">
1. Paticipants get 30% of their investment.
</li><li class="list-group-item">
2. 10% Referral bonus on every participant who they refer.
</li><li class="list-group-item">
3. There is no fear of fake users as defaulters accounts will be blocked and automatically deleted from the system after 2 hours.
</li><li class="list-group-item">
4. No fear of being purged out as there is no purge button. Unpaid reservations are automatically rescheduled in next list.
</li><li class="list-group-item">
5. Approval and confirmation made easy as donor just need to call their upline and get confirmed instantly.
</li><li class="list-group-item">
6. Swift support facility to ensure quick and adequate response to individual requests and complains.
</li><li class="list-group-item">
7. Secure Transactions: The security of all transactions are well-protected.</li>
</ul></p>

</p>
</div>
</div>
</div>

    <div class="col-lg-12">
                    <div class="panel panel-default about-app">
                        <div class="panel-body text-center"> 
                            <h1>Rules for participation</h1> <hr>
                            <p>
<p>


<ul class="list-group">
<li class="list-group-item">1. You are under obligation to make payments for reservations made within the shortest possible period.
</li><li class="list-group-item">

2. You are under obligation to confirm fellow participant immediately for payments received.
</li><li class="list-group-item">

3. It is impossible to make a new reservation if you have an ongoing transaction.
</li><li class="list-group-item">

4. For safety reasons, Account details can never be edited.
</li><li class="list-group-item">

5. Defaulters are considered as unserious and are removed from the system without hesitation.
</li></ul>
<p>
<ul class="list-group">
</ul>
    </p>
</p></p></div></div></div>

                </div>             
            </div>

            

        </div>

   

            
            
            
          
            
  

 </div>
 </div>



            
            </div>

                
            </div>

            </div>
        </div>
    </div>


        <?php require $this->footer; ?>


      