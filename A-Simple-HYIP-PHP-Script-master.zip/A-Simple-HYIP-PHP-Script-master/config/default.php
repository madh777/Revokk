<?php 

$CONF["auralz_logo_path"]     = "public/images/logo.png";


$CONF["mylala"]    = "admin";
$CONF["mylala_password"] = "12345678900";

$CONF["time_limit"]           = "2 hours"; // time limit for payment
$CONF["datetime"]             = date("Y-m-d H:i:s");
$CONF["date"]                 = date("Y-m-d");
$CONF["time"] 	              = date("h:i:sa");
$CONF["db_time"]              = date("H:i:s");
$CONF['pay_limit'] =  2;
$CONF['clean_up_minutes'] =1; 
$CONF['max_no_of_people_listed'] = 20;



$CONF["min_pledge"]   = 20000; //$40
$CONF["max_pledge"]   = 250000; //$500





?>