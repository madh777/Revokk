<?php 



define("BASEURL", TRUE);



require 'app/init.php';





$bootstrap = new bootstrap();



//die("under construction");

//require("coming_soon.php");







?>