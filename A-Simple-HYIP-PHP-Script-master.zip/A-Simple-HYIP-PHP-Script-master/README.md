# Please this is entirely for educative purposes and should not be used for decietful gains

1: Install XAMPP or WAMP
2: Download the files and copy to your htdocs or www folder
3: Create your database and import the sql file
4: Rename the databse name and pasword in the config/const.php

Run your script in your browser
